# class inside another class
# class Outer:
#   class Inner: