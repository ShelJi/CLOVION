# collection = single "variable" used to store multiple values
# List = [] ordered and changable. Duplicates ok
# Set = {} unordered and immutable(not changing, or unable to be changed), but Add/Remove ok. No duplicates
# Tuple = () ordered and unchangeable. Duplicates ok. FASTER 