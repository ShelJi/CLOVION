a = 1
b = 1

class Calculator:

    def add(num1, num2):
        return num1 + num2

calc = Calculator
c = add(a,b)

print(c)