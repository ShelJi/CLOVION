def palindrome(data):
    return data == data[::-1]

print(palindrome("wow"))