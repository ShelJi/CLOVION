is_true = False
number_1 = 10
number_2 = 10

"""
= assigning operator
== compparison operator
<
>
<=
>=
!= not equal
"""

if number_1 < 11:
    print("Hello ")

# elif is_true:
#     print("first elif")

# elif is_true:
#     print("second elif")

else:
    print("Else condition")

# task: vote age verify